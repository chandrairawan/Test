import java.util.Scanner;

/**
 * class testCust here.
 *
 * @author Abdul Chandra Irawan
 * @version 2018.03.09
 */
public class testCust
{
    public testCust(){
        Customer cust = new Customer("Platinum");
        cust.empPoint(320);
        cust.empBelanja(600);
        cust.printCustomer();
    }
    
    public static void main(String []args){
        Customer budi = new Customer("Platinum");
        budi.empPoint(200);
        budi.empBelanja(500);
        budi.printCustomer();
        
        Customer tony = new Customer("Gold");
        tony.empPoint(396);
        tony.empBelanja(100);
        tony.printCustomer();
        
        Customer doni = new Customer("Platinum");
        doni.empPoint(200);
        doni.empBelanja(60);
        doni.printCustomer();
        
        Customer nia = new Customer("Silver");
        nia.empPoint(396);
        nia.empBelanja(10);
        nia.printCustomer();
    }
}
