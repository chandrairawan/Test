
/**
 * Class Customer.
 *
 * @author Abdul Chandra Irawan
 * @version 2018.03.09
 */
public class Customer
{
    // instance variables
    String tipeCustomer;
    double point, belanja, diskon;
    

    /**
     * Constructor untuk class Customer
     */
    public Customer(String tipeCustomer)
    {
        // initialise instance variables
        this.tipeCustomer = tipeCustomer;
    }
    
    public void empPoint (double empPoint){
        point = empPoint;
    }
    
    public void empBelanja(double empBelanja){
        belanja = empBelanja;
    }
    
    public double getDiscount(){
        double persen=0 , nPoint=0;
        
        if (tipeCustomer == "Platinum" || tipeCustomer == "platinum"){
            persen = 50;
            if (point >= 100 && point <= 300){nPoint=35;}
            else if (point >= 301 && point <= 500){nPoint=50;}
            else if (point < 500){nPoint=68;}
            else {nPoint=0;}
        }
        
        else if (tipeCustomer == "Gold" || tipeCustomer == "gold"){
            persen = 25;
            if (point >= 100 && point <= 300){nPoint=25;}
            else if (point >= 301 && point <= 500){nPoint=34;}
            else if (point < 500){nPoint=52;}
            else {nPoint=0;}
        }
        
        else if (tipeCustomer == "Silver" || tipeCustomer == "silver"){
            persen = 10;
            if (point >= 100 && point <= 300){nPoint=12;}
            else if (point >= 301 && point <= 500){nPoint=27;}
            else if (point < 500){nPoint=39;}
            else {nPoint=0;}
        }
        
        return belanja * (persen/100) + nPoint;
    }
    
    public double getTotal(){
        double total=0, discount=0;
        
        if (getDiscount()>=belanja){discount=belanja;}
        else {discount = getDiscount();}
        return belanja - discount;
    }

    public void printCustomer(){
        System.out.println("Tipe Customer : "+ tipeCustomer);
        System.out.println("Point Reward  : "+ point);
        System.out.println("TOTAL_BELANJA : "+ belanja);
        System.out.println("Diskon        : "+ getDiscount());
        System.out.println("Total Bayar   : "+ getTotal());
        System.out.println("==========================");
    }
}
