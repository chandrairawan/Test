
/**
 * Program utama yang dapat membalik setiap masukan di sisi kanan dan kiri berlawanan.
 *
 * @author Abdul Chandra Irawan
 * @version 2018.03.08
 */
public class main
{
    // instance variables - replace the example below with your own
    private String input;

    /**
     * Constructor for objects of class main
     */
    public main(String input)
    {
        char[] c_arr = input.toCharArray();
        int awal = 0;
        char temp = 0;
        int akhir = c_arr.length-1;
        int sisikiri = akhir/2;
        int sisikanan = akhir/2 + 1;
        System.out.println();
        System.out.println("input = "+ input);
        
        if(akhir%2==0){
            while(sisikiri>awal){
                //System.out.println(sisikiri);
                //System.out.println(awal);
                temp = c_arr[awal];
                c_arr[awal] = c_arr[sisikiri-1];
                c_arr[sisikiri-1] = temp;
                sisikiri--;
                awal++;
            }
            
            while(akhir>=sisikanan){
                // System.out.println(akhir);
                // System.out.println(sisikanan);
                temp = c_arr[sisikanan];
                c_arr[sisikanan] = c_arr[akhir];
                c_arr[akhir] = temp;
                akhir--;
                sisikanan++;
            }
        }
        
        else {
            while(sisikiri>awal){
                //System.out.println(sisikiri);
                //System.out.println(awal);
                temp = c_arr[awal];
                c_arr[awal] = c_arr[sisikiri];
                c_arr[sisikiri] = temp;
                sisikiri--;
                awal++;
            }
            
            while(akhir>=sisikanan){
                // System.out.println(akhir);
                // System.out.println(sisikanan);
                temp = c_arr[sisikanan];
                c_arr[sisikanan] = c_arr[akhir];
                c_arr[akhir] = temp;
                akhir--;
                sisikanan++;
            }
        }
        System.out.print("output = ");
        System.out.println(c_arr);
    }
    
    public static void main(String args[]) {
        main try1 = new main("123456");
        main try2 = new main("1234567");
        main try3 = new main("ABCDEF");
        main try4 = new main("ABCDEFG");
        main try5 = new main("GABAG");
        main try6 = new main("BA3&H-M");
        main try7 = new main("ABC45623MUK9");
    }
}
